# SafeGuard - Personal Safety Mobile App

## Overview

SafeGuard is a React Native/Expo mobile application designed for personal safety. The app allows users to trigger emergency alerts through voice commands, manual activation, or shake detection. When activated, it sends SMS alerts with location data to emergency contacts and can initiate emergency calls. Key features include:

- Multi-layer authentication (OTP, password, biometric)
- Emergency contact management
- Safe route planning and tracking
- User profile with physical identification details (for emergency situations)
- Voice-activated emergency triggers ("HELP" keyword)
- Silent emergency mode for discreet alerts

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React Native with Expo SDK 54
- **Navigation**: React Navigation v7 with bottom tabs and native stack
- **State Management**: TanStack React Query for server state, React Context for auth/emergency states
- **UI Components**: Custom themed components with Reanimated for animations
- **Styling**: StyleSheet with theme-aware colors supporting light/dark modes
- **Keyboard Handling**: react-native-keyboard-controller for better keyboard interactions

### Backend Architecture
- **Runtime**: Express.js server with TypeScript
- **API Style**: RESTful JSON API
- **Build Tool**: esbuild for server bundling, Expo for client
- **Database ORM**: Drizzle ORM with PostgreSQL dialect

### Authentication Flow
1. First-time users: Phone verification via OTP
2. Password setup after initial verification
3. Optional biometric (fingerprint) enrollment
4. Subsequent launches require password + optional biometric unlock

### Data Models
- **Users**: Phone number, password hash, fingerprint settings, verification status
- **User Profiles**: Physical identification details (height, weight, skin tone, eye color, etc.)
- **Emergency Contacts**: Name, phone, relationship, primary contact flag
- **Saved Routes**: Start/end coordinates with addresses
- **Emergency Events**: Event type, trigger method, location, status, timestamps

### Path Aliases
- `@/` maps to `./client/` for client-side imports
- `@shared/` maps to `./shared/` for shared types/schema

### Key Design Patterns
- **Error Boundaries**: Class component wrapping entire app for crash recovery
- **Context Providers**: AuthContext and EmergencyContext wrap navigation
- **Query Client**: Centralized API request handling with user ID injection
- **Secure Storage**: expo-secure-store for sensitive data (falls back to localStorage on web)

## External Dependencies

### Database
- PostgreSQL via Drizzle ORM
- Schema defined in `shared/schema.ts`
- Migrations managed via drizzle-kit

### Native Capabilities (Expo)
- `expo-local-authentication`: Biometric authentication
- `expo-location`: GPS tracking for emergency alerts and safe routes
- `expo-secure-store`: Encrypted credential storage
- `expo-av`: Audio playback for alarm sounds
- `expo-haptics`: Vibration feedback

### Third-Party Services
- **OTP Verification**: API structure prepared for Vonage integration (currently mock implementation)
- **SMS/Calling**: Prepared for native SMS/call integration (platform-specific permissions configured)

### Platform Permissions Required
- Microphone (voice trigger)
- Location (emergency alerts, route tracking)
- Biometric authentication
- SMS sending (Android)
- Phone calling (Android)