import React, { useState, useEffect } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MainTabNavigator from "@/navigation/MainTabNavigator";
import LoginScreen from "@/screens/LoginScreen";
import UnlockScreen from "@/screens/UnlockScreen";
import EmergencyAlarmScreen from "@/screens/EmergencyAlarmScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useAuth, AuthProvider } from "@/contexts/AuthContext";
import { useEmergency, EmergencyProvider } from "@/contexts/EmergencyContext";
import { View, ActivityIndicator, StyleSheet } from "react-native";
import { SafetyColors } from "@/constants/theme";
import { useTheme } from "@/hooks/useTheme";

export type RootStackParamList = {
  Login: undefined;
  Unlock: undefined;
  Main: undefined;
  EmergencyAlarm: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

function RootNavigator() {
  const screenOptions = useScreenOptions();
  const { isLoading, userId, hasPassword, hasFingerprintEnabled, isAuthenticated } = useAuth();
  const { isEmergencyActive } = useEmergency();
  const { theme } = useTheme();
  const [isUnlocked, setIsUnlocked] = useState(false);

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={SafetyColors.safeGreen} />
      </View>
    );
  }

  const needsLogin = !userId;
  const needsSetup = userId && (!hasPassword);
  const needsUnlock = userId && hasPassword && !isUnlocked;

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      {isEmergencyActive ? (
        <Stack.Screen
          name="EmergencyAlarm"
          component={EmergencyAlarmScreen}
          options={{
            headerShown: false,
            gestureEnabled: false,
            animation: "fade",
          }}
        />
      ) : needsLogin || needsSetup ? (
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
      ) : needsUnlock ? (
        <Stack.Screen
          name="Unlock"
          options={{ headerShown: false }}
        >
          {() => <UnlockScreen onUnlock={() => setIsUnlocked(true)} />}
        </Stack.Screen>
      ) : (
        <Stack.Screen
          name="Main"
          component={MainTabNavigator}
          options={{ headerShown: false }}
        />
      )}
    </Stack.Navigator>
  );
}

export default function RootStackNavigator() {
  return (
    <AuthProvider>
      <EmergencyProvider>
        <RootNavigator />
      </EmergencyProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
