import React, { createContext, useContext, useState, useRef, ReactNode } from "react";
import { Audio } from "expo-av";
import * as Haptics from "expo-haptics";
import * as Location from "expo-location";
import { apiRequest, getApiUrl } from "@/lib/query-client";

interface EmergencyState {
  isEmergencyActive: boolean;
  triggerType: "voice" | "shake" | "manual" | null;
  currentLocation: { latitude: number; longitude: number; address?: string } | null;
  smsSent: boolean;
  callsMade: boolean;
  isSilentMode: boolean;
}

interface EmergencyContextType extends EmergencyState {
  triggerEmergency: (type: "voice" | "shake" | "manual", silent?: boolean) => Promise<void>;
  stopEmergency: () => Promise<void>;
  setSilentMode: (silent: boolean) => void;
}

const EmergencyContext = createContext<EmergencyContextType | undefined>(undefined);

export function EmergencyProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<EmergencyState>({
    isEmergencyActive: false,
    triggerType: null,
    currentLocation: null,
    smsSent: false,
    callsMade: false,
    isSilentMode: false,
  });

  const soundRef = useRef<Audio.Sound | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const playAlarm = async () => {
    if (state.isSilentMode) return;
    
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        staysActiveInBackground: true,
        shouldDuckAndroid: false,
      });
    } catch (error) {
      console.log("Error setting audio mode:", error);
    }
  };

  const stopAlarm = async () => {
    if (soundRef.current) {
      await soundRef.current.stopAsync();
      await soundRef.current.unloadAsync();
      soundRef.current = null;
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        return null;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      const [address] = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      const addressString = address
        ? `${address.street || ""} ${address.city || ""} ${address.region || ""} ${address.country || ""}`.trim()
        : undefined;

      return {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        address: addressString,
      };
    } catch (error) {
      console.log("Error getting location:", error);
      return null;
    }
  };

  const sendEmergencyAlerts = async (location: { latitude: number; longitude: number; address?: string } | null) => {
    try {
      const response = await apiRequest("POST", "/api/emergency/trigger", {
        location,
        triggerType: state.triggerType,
      });
      
      if (response.ok) {
        const data = await response.json();
        setState((prev) => ({
          ...prev,
          smsSent: data.smsSent,
          callsMade: data.callsMade,
        }));
      }
    } catch (error) {
      console.log("Error sending emergency alerts:", error);
    }
  };

  const triggerEmergency = async (type: "voice" | "shake" | "manual", silent: boolean = false) => {
    if (state.isEmergencyActive) return;

    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);

    const location = await getCurrentLocation();

    setState({
      isEmergencyActive: true,
      triggerType: type,
      currentLocation: location,
      smsSent: false,
      callsMade: false,
      isSilentMode: silent,
    });

    if (!silent) {
      await playAlarm();
    }

    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);

    intervalRef.current = setInterval(() => {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    }, 2000);

    await sendEmergencyAlerts(location);
  };

  const stopEmergency = async () => {
    await stopAlarm();
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    try {
      await apiRequest("POST", "/api/emergency/stop", {});
    } catch (error) {
      console.log("Error stopping emergency:", error);
    }

    setState({
      isEmergencyActive: false,
      triggerType: null,
      currentLocation: null,
      smsSent: false,
      callsMade: false,
      isSilentMode: false,
    });

    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const setSilentMode = (silent: boolean) => {
    setState((prev) => ({ ...prev, isSilentMode: silent }));
  };

  return (
    <EmergencyContext.Provider
      value={{
        ...state,
        triggerEmergency,
        stopEmergency,
        setSilentMode,
      }}
    >
      {children}
    </EmergencyContext.Provider>
  );
}

export function useEmergency() {
  const context = useContext(EmergencyContext);
  if (!context) {
    throw new Error("useEmergency must be used within an EmergencyProvider");
  }
  return context;
}
