import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  userId: string | null;
  phoneNumber: string | null;
  hasPassword: boolean;
  hasFingerprintEnabled: boolean;
}

interface AuthContextType extends AuthState {
  login: (userId: string, phoneNumber: string) => Promise<void>;
  logout: () => Promise<void>;
  setPassword: (password: string) => Promise<void>;
  verifyPassword: (password: string) => Promise<boolean>;
  setFingerprintEnabled: (enabled: boolean) => Promise<void>;
  checkAuthState: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_KEYS = {
  USER_ID: "safeguard_user_id",
  PHONE_NUMBER: "safeguard_phone_number",
  PASSWORD_HASH: "safeguard_password_hash",
  FINGERPRINT_ENABLED: "safeguard_fingerprint_enabled",
};

function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(16);
}

async function getSecureItem(key: string): Promise<string | null> {
  try {
    if (Platform.OS === "web") {
      return localStorage.getItem(key);
    }
    return await SecureStore.getItemAsync(key);
  } catch {
    return null;
  }
}

async function setSecureItem(key: string, value: string): Promise<void> {
  try {
    if (Platform.OS === "web") {
      localStorage.setItem(key, value);
    } else {
      await SecureStore.setItemAsync(key, value);
    }
  } catch (error) {
    console.warn("Failed to set secure item:", key);
  }
}

async function deleteSecureItem(key: string): Promise<void> {
  try {
    if (Platform.OS === "web") {
      localStorage.removeItem(key);
    } else {
      await SecureStore.deleteItemAsync(key);
    }
  } catch (error) {
    console.warn("Failed to delete secure item:", key);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: true,
    userId: null,
    phoneNumber: null,
    hasPassword: false,
    hasFingerprintEnabled: false,
  });

  useEffect(() => {
    checkAuthState();
  }, []);

  const checkAuthState = async () => {
    try {
      const userId = await getSecureItem(AUTH_KEYS.USER_ID);
      const phoneNumber = await getSecureItem(AUTH_KEYS.PHONE_NUMBER);
      const passwordHash = await getSecureItem(AUTH_KEYS.PASSWORD_HASH);
      const fingerprintEnabled = await getSecureItem(AUTH_KEYS.FINGERPRINT_ENABLED);

      setState({
        isAuthenticated: false,
        isLoading: false,
        userId,
        phoneNumber,
        hasPassword: !!passwordHash,
        hasFingerprintEnabled: fingerprintEnabled === "true",
      });
    } catch (error) {
      console.error("Error checking auth state:", error);
      setState((prev) => ({ ...prev, isLoading: false }));
    }
  };

  const login = async (userId: string, phoneNumber: string) => {
    await setSecureItem(AUTH_KEYS.USER_ID, userId);
    await setSecureItem(AUTH_KEYS.PHONE_NUMBER, phoneNumber);
    
    const passwordHash = await getSecureItem(AUTH_KEYS.PASSWORD_HASH);
    const fingerprintEnabled = await getSecureItem(AUTH_KEYS.FINGERPRINT_ENABLED);
    
    setState({
      isAuthenticated: true,
      isLoading: false,
      userId,
      phoneNumber,
      hasPassword: !!passwordHash,
      hasFingerprintEnabled: fingerprintEnabled === "true",
    });
  };

  const logout = async () => {
    await deleteSecureItem(AUTH_KEYS.USER_ID);
    await deleteSecureItem(AUTH_KEYS.PHONE_NUMBER);
    await deleteSecureItem(AUTH_KEYS.PASSWORD_HASH);
    await deleteSecureItem(AUTH_KEYS.FINGERPRINT_ENABLED);
    
    setState({
      isAuthenticated: false,
      isLoading: false,
      userId: null,
      phoneNumber: null,
      hasPassword: false,
      hasFingerprintEnabled: false,
    });
  };

  const setPassword = async (password: string) => {
    const hash = simpleHash(password);
    await setSecureItem(AUTH_KEYS.PASSWORD_HASH, hash);
    setState((prev) => ({ ...prev, hasPassword: true }));
  };

  const verifyPassword = async (password: string): Promise<boolean> => {
    const storedHash = await getSecureItem(AUTH_KEYS.PASSWORD_HASH);
    if (!storedHash) return false;
    
    const inputHash = simpleHash(password);
    return storedHash === inputHash;
  };

  const setFingerprintEnabled = async (enabled: boolean) => {
    await setSecureItem(AUTH_KEYS.FINGERPRINT_ENABLED, enabled ? "true" : "false");
    setState((prev) => ({ ...prev, hasFingerprintEnabled: enabled }));
  };

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        logout,
        setPassword,
        verifyPassword,
        setFingerprintEnabled,
        checkAuthState,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
