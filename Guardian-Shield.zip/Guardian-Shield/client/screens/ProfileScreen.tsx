import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  Alert,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors } from "@/constants/theme";
import { apiRequest } from "@/lib/query-client";
import { useAuth } from "@/contexts/AuthContext";
import type { UserProfile } from "@shared/schema";

const GENDERS = ["Male", "Female", "Other", "Prefer not to say"];
const SKIN_TONES = ["Fair", "Light", "Medium", "Olive", "Brown", "Dark"];
const EYE_COLORS = ["Brown", "Blue", "Green", "Hazel", "Gray", "Amber", "Other"];
const HAIR_COLORS = ["Black", "Brown", "Blonde", "Red", "Gray", "White", "Other"];

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { logout, phoneNumber } = useAuth();
  const queryClient = useQueryClient();

  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [skinTone, setSkinTone] = useState("");
  const [eyeColor, setEyeColor] = useState("");
  const [hairColor, setHairColor] = useState("");
  const [distinguishingMarks, setDistinguishingMarks] = useState("");

  const { data: profile, isLoading } = useQuery<UserProfile>({
    queryKey: ["/api/profile"],
  });

  useEffect(() => {
    if (profile) {
      setFullName(profile.fullName || "");
      setAge(profile.age?.toString() || "");
      setGender(profile.gender || "");
      setHeight(profile.height || "");
      setWeight(profile.weight || "");
      setSkinTone(profile.skinTone || "");
      setEyeColor(profile.eyeColor || "");
      setHairColor(profile.hairColor || "");
      setDistinguishingMarks(profile.distinguishingMarks || "");
    }
  }, [profile]);

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<UserProfile>) => {
      const response = await apiRequest("PATCH", "/api/profile", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setIsEditing(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  const handleSave = () => {
    updateMutation.mutate({
      fullName: fullName || null,
      age: age ? parseInt(age) : null,
      gender: gender || null,
      height: height || null,
      weight: weight || null,
      skinTone: skinTone || null,
      eyeColor: eyeColor || null,
      hairColor: hairColor || null,
      distinguishingMarks: distinguishingMarks || null,
    });
  };

  const handleLogout = () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout? Your emergency settings will remain active.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Logout",
          style: "destructive",
          onPress: () => logout(),
        },
      ]
    );
  };

  const renderChipSelector = (
    label: string,
    options: string[],
    value: string,
    onChange: (val: string) => void
  ) => (
    <View style={styles.inputGroup}>
      <ThemedText style={[Typography.small, styles.inputLabel]}>{label}</ThemedText>
      <View style={styles.chipGrid}>
        {options.map((option) => (
          <Pressable
            key={option}
            style={[
              styles.chip,
              {
                backgroundColor: value === option ? SafetyColors.safeGreen : theme.backgroundSecondary,
              },
            ]}
            onPress={() => isEditing && onChange(option)}
            disabled={!isEditing}
          >
            <ThemedText
              style={[
                Typography.small,
                { color: value === option ? "#FFFFFF" : theme.text },
              ]}
            >
              {option}
            </ThemedText>
          </Pressable>
        ))}
      </View>
    </View>
  );

  if (isLoading) {
    return (
      <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SafetyColors.safeGreen} />
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing["3xl"],
          },
        ]}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
      >
        <View style={styles.header}>
          <View style={[styles.avatarLarge, { backgroundColor: SafetyColors.safeGreen }]}>
            <ThemedText style={styles.avatarLargeText}>
              {fullName ? fullName.charAt(0).toUpperCase() : "?"}
            </ThemedText>
          </View>
          <ThemedText style={[Typography.h3, styles.userName]}>
            {fullName || "Set Your Name"}
          </ThemedText>
          <ThemedText style={[Typography.small, { color: theme.textSecondary }]}>
            {phoneNumber}
          </ThemedText>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <ThemedText style={[Typography.small, { color: theme.textSecondary }]}>
              PERSONAL DETAILS
            </ThemedText>
            <Pressable onPress={() => (isEditing ? handleSave() : setIsEditing(true))}>
              {updateMutation.isPending ? (
                <ActivityIndicator size="small" color={SafetyColors.safeGreen} />
              ) : (
                <ThemedText style={[Typography.bodyMedium, { color: SafetyColors.safeGreen }]}>
                  {isEditing ? "Save" : "Edit"}
                </ThemedText>
              )}
            </Pressable>
          </View>

          <Card style={styles.formCard}>
            <View style={styles.inputGroup}>
              <ThemedText style={[Typography.small, styles.inputLabel]}>Full Name</ThemedText>
              <TextInput
                style={[
                  styles.input,
                  {
                    backgroundColor: isEditing ? theme.inputBackground : theme.backgroundSecondary,
                    borderColor: theme.inputBorder,
                    color: theme.text,
                  },
                ]}
                placeholder="Enter your full name"
                placeholderTextColor={theme.textSecondary}
                value={fullName}
                onChangeText={setFullName}
                editable={isEditing}
              />
            </View>

            <View style={styles.row}>
              <View style={[styles.inputGroup, { flex: 1 }]}>
                <ThemedText style={[Typography.small, styles.inputLabel]}>Age</ThemedText>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: isEditing ? theme.inputBackground : theme.backgroundSecondary,
                      borderColor: theme.inputBorder,
                      color: theme.text,
                    },
                  ]}
                  placeholder="Age"
                  placeholderTextColor={theme.textSecondary}
                  keyboardType="number-pad"
                  value={age}
                  onChangeText={setAge}
                  editable={isEditing}
                />
              </View>
              <View style={{ width: Spacing.md }} />
              <View style={[styles.inputGroup, { flex: 2 }]}>
                <ThemedText style={[Typography.small, styles.inputLabel]}>Gender</ThemedText>
                <View style={styles.genderRow}>
                  {GENDERS.slice(0, 3).map((g) => (
                    <Pressable
                      key={g}
                      style={[
                        styles.genderChip,
                        {
                          backgroundColor: gender === g ? SafetyColors.safeGreen : theme.backgroundSecondary,
                        },
                      ]}
                      onPress={() => isEditing && setGender(g)}
                      disabled={!isEditing}
                    >
                      <ThemedText
                        style={[Typography.caption, { color: gender === g ? "#FFFFFF" : theme.text }]}
                      >
                        {g}
                      </ThemedText>
                    </Pressable>
                  ))}
                </View>
              </View>
            </View>
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
            PHYSICAL CHARACTERISTICS
          </ThemedText>
          <ThemedText style={[Typography.caption, { color: theme.textSecondary, marginBottom: Spacing.md }]}>
            This information helps identify you in case of emergency
          </ThemedText>

          <Card style={styles.formCard}>
            <View style={styles.row}>
              <View style={[styles.inputGroup, { flex: 1 }]}>
                <ThemedText style={[Typography.small, styles.inputLabel]}>Height</ThemedText>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: isEditing ? theme.inputBackground : theme.backgroundSecondary,
                      borderColor: theme.inputBorder,
                      color: theme.text,
                    },
                  ]}
                  placeholder={'e.g., 5\'8"'}
                  placeholderTextColor={theme.textSecondary}
                  value={height}
                  onChangeText={setHeight}
                  editable={isEditing}
                />
              </View>
              <View style={{ width: Spacing.md }} />
              <View style={[styles.inputGroup, { flex: 1 }]}>
                <ThemedText style={[Typography.small, styles.inputLabel]}>Weight</ThemedText>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: isEditing ? theme.inputBackground : theme.backgroundSecondary,
                      borderColor: theme.inputBorder,
                      color: theme.text,
                    },
                  ]}
                  placeholder="e.g., 150 lbs"
                  placeholderTextColor={theme.textSecondary}
                  value={weight}
                  onChangeText={setWeight}
                  editable={isEditing}
                />
              </View>
            </View>

            {renderChipSelector("Skin Tone", SKIN_TONES, skinTone, setSkinTone)}
            {renderChipSelector("Eye Color", EYE_COLORS, eyeColor, setEyeColor)}
            {renderChipSelector("Hair Color", HAIR_COLORS, hairColor, setHairColor)}

            <View style={styles.inputGroup}>
              <ThemedText style={[Typography.small, styles.inputLabel]}>Distinguishing Marks</ThemedText>
              <TextInput
                style={[
                  styles.textArea,
                  {
                    backgroundColor: isEditing ? theme.inputBackground : theme.backgroundSecondary,
                    borderColor: theme.inputBorder,
                    color: theme.text,
                  },
                ]}
                placeholder="Scars, tattoos, birthmarks, etc."
                placeholderTextColor={theme.textSecondary}
                value={distinguishingMarks}
                onChangeText={setDistinguishingMarks}
                editable={isEditing}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
            ACCOUNT
          </ThemedText>

          <Card style={styles.menuCard}>
            <Pressable style={[styles.menuItem, { borderBottomColor: theme.divider }]}>
              <Feather name="lock" size={20} color={theme.text} />
              <ThemedText style={[Typography.body, styles.menuText]}>Change Password</ThemedText>
              <Feather name="chevron-right" size={20} color={theme.textSecondary} />
            </Pressable>
            <Pressable style={[styles.menuItem, { borderBottomColor: theme.divider }]}>
              <Feather name="smartphone" size={20} color={theme.text} />
              <ThemedText style={[Typography.body, styles.menuText]}>Update Fingerprint</ThemedText>
              <Feather name="chevron-right" size={20} color={theme.textSecondary} />
            </Pressable>
            <Pressable style={styles.menuItem} onPress={handleLogout}>
              <Feather name="log-out" size={20} color={SafetyColors.alertRed} />
              <ThemedText style={[Typography.body, styles.menuText, { color: SafetyColors.alertRed }]}>
                Logout
              </ThemedText>
              <Feather name="chevron-right" size={20} color={SafetyColors.alertRed} />
            </Pressable>
          </Card>
        </View>
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  avatarLargeText: {
    color: "#FFFFFF",
    fontSize: 32,
    fontWeight: "600",
  },
  userName: {
    marginBottom: Spacing.xs,
  },
  section: {
    marginBottom: Spacing["2xl"],
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    marginBottom: Spacing.xs,
  },
  formCard: {
    padding: Spacing.lg,
  },
  inputGroup: {
    marginBottom: Spacing.lg,
  },
  inputLabel: {
    marginBottom: Spacing.xs,
  },
  input: {
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  textArea: {
    minHeight: 80,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    fontSize: 16,
  },
  row: {
    flexDirection: "row",
  },
  genderRow: {
    flexDirection: "row",
    gap: Spacing.xs,
  },
  genderChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  chipGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  chip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  menuCard: {
    padding: 0,
    overflow: "hidden",
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderBottomWidth: 1,
  },
  menuText: {
    flex: 1,
    marginLeft: Spacing.md,
  },
});
