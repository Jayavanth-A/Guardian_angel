import React, { useState, useEffect, useRef } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  Alert,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Location from "expo-location";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors, Shadows } from "@/constants/theme";
import { apiRequest } from "@/lib/query-client";

interface RouteInfo {
  distance: string;
  duration: string;
  startAddress: string;
  endAddress: string;
}

export default function SafeRouteScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [currentLocation, setCurrentLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentAddress, setCurrentAddress] = useState("");
  const [destination, setDestination] = useState("");
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(true);
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    setLocationLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setError("Location permission is required for safe route tracking");
        setLocationLoading(false);
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      setCurrentLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      const [address] = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      if (address) {
        const addressStr = `${address.street || ""} ${address.city || ""}, ${address.region || ""}`.trim();
        setCurrentAddress(addressStr);
      }
    } catch (err) {
      setError("Failed to get current location");
    } finally {
      setLocationLoading(false);
    }
  };

  const handleCalculateRoute = async () => {
    if (!destination.trim()) {
      Alert.alert("Error", "Please enter a destination");
      return;
    }

    if (!currentLocation) {
      Alert.alert("Error", "Current location not available");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await apiRequest("POST", "/api/routes/calculate", {
        startLat: currentLocation.latitude,
        startLng: currentLocation.longitude,
        startAddress: currentAddress,
        destination: destination.trim(),
      });

      if (response.ok) {
        const data = await response.json();
        setRouteInfo({
          distance: data.distance,
          duration: data.duration,
          startAddress: currentAddress,
          endAddress: data.endAddress,
        });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        const errorData = await response.json();
        setError(errorData.message || "Failed to calculate route");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleStartTracking = async () => {
    if (!routeInfo) return;

    setIsTracking(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert(
      "Tracking Started",
      "Your location is now being monitored. Your emergency contacts will be notified if you deviate from your route.",
      [{ text: "OK" }]
    );
  };

  const handleStopTracking = () => {
    setIsTracking(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    Alert.alert("Tracking Stopped", "Route tracking has been disabled.");
  };

  const renderPermissionRequest = () => (
    <View style={styles.permissionContainer}>
      <View style={[styles.permissionIcon, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="map-pin" size={48} color={SafetyColors.warningOrange} />
      </View>
      <ThemedText style={[Typography.h4, styles.permissionTitle]}>Location Access Required</ThemedText>
      <ThemedText style={[Typography.body, styles.permissionText, { color: theme.textSecondary }]}>
        SafeGuard needs your location to track your route and alert contacts if you deviate
      </ThemedText>
      <Pressable
        style={({ pressed }) => [
          styles.permissionButton,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={getCurrentLocation}
      >
        <ThemedText style={[Typography.button, { color: "#FFFFFF" }]}>Enable Location</ThemedText>
      </Pressable>
    </View>
  );

  if (locationLoading) {
    return (
      <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SafetyColors.safeGreen} />
          <ThemedText style={[Typography.body, { marginTop: Spacing.lg, color: theme.textSecondary }]}>
            Getting your location...
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  if (!currentLocation) {
    return (
      <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
        <View
          style={[
            styles.content,
            {
              paddingTop: headerHeight + Spacing.xl,
              paddingBottom: tabBarHeight + Spacing.xl,
              justifyContent: "center",
            },
          ]}
        >
          {renderPermissionRequest()}
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing["3xl"],
          },
        ]}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
      >
        {isTracking ? (
          <Card style={[styles.trackingCard, { backgroundColor: SafetyColors.safeGreen }]}>
            <View style={styles.trackingHeader}>
              <View style={styles.trackingPulse} />
              <ThemedText style={[Typography.bodyMedium, { color: "#FFFFFF" }]}>
                Route Tracking Active
              </ThemedText>
            </View>
            <ThemedText style={[Typography.small, { color: "rgba(255,255,255,0.8)" }]}>
              Your contacts will be notified if you deviate from your planned route
            </ThemedText>
          </Card>
        ) : null}

        <View style={styles.section}>
          <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
            START POINT
          </ThemedText>
          <Card style={styles.locationCard}>
            <View style={styles.locationRow}>
              <View style={[styles.locationIcon, { backgroundColor: SafetyColors.safeGreen }]}>
                <Feather name="navigation" size={16} color="#FFFFFF" />
              </View>
              <View style={styles.locationInfo}>
                <ThemedText style={Typography.caption}>Current Location</ThemedText>
                <ThemedText style={Typography.body} numberOfLines={2}>
                  {currentAddress || "Getting address..."}
                </ThemedText>
              </View>
              <Pressable onPress={getCurrentLocation} style={styles.refreshButton}>
                <Feather name="refresh-cw" size={18} color={theme.textSecondary} />
              </Pressable>
            </View>
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
            DESTINATION
          </ThemedText>
          <Card style={styles.inputCard}>
            <View style={styles.inputRow}>
              <View style={[styles.locationIcon, { backgroundColor: SafetyColors.alertRed }]}>
                <Feather name="map-pin" size={16} color="#FFFFFF" />
              </View>
              <TextInput
                style={[styles.destinationInput, { color: theme.text }]}
                placeholder="Enter your destination address"
                placeholderTextColor={theme.textSecondary}
                value={destination}
                onChangeText={setDestination}
                editable={!isTracking}
              />
            </View>
          </Card>
        </View>

        {error ? (
          <Card style={[styles.errorCard, { backgroundColor: "rgba(198, 40, 40, 0.1)" }]}>
            <Feather name="alert-circle" size={20} color={SafetyColors.alertRed} />
            <ThemedText style={[Typography.small, { color: SafetyColors.alertRed, marginLeft: Spacing.sm, flex: 1 }]}>
              {error}
            </ThemedText>
          </Card>
        ) : null}

        {!isTracking ? (
          <Pressable
            style={({ pressed }) => [
              styles.calculateButton,
              { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
            ]}
            onPress={handleCalculateRoute}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <>
                <Feather name="search" size={20} color="#FFFFFF" />
                <ThemedText style={[Typography.button, styles.buttonText]}>Calculate Route</ThemedText>
              </>
            )}
          </Pressable>
        ) : null}

        {routeInfo ? (
          <View style={styles.section}>
            <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
              ROUTE DETAILS
            </ThemedText>
            <Card style={styles.routeCard}>
              <View style={styles.routeStats}>
                <View style={styles.routeStat}>
                  <Feather name="clock" size={24} color={SafetyColors.infoBlue} />
                  <ThemedText style={[Typography.h4, styles.statValue]}>{routeInfo.duration}</ThemedText>
                  <ThemedText style={[Typography.caption, { color: theme.textSecondary }]}>Duration</ThemedText>
                </View>
                <View style={[styles.routeDivider, { backgroundColor: theme.divider }]} />
                <View style={styles.routeStat}>
                  <Feather name="map" size={24} color={SafetyColors.safeGreen} />
                  <ThemedText style={[Typography.h4, styles.statValue]}>{routeInfo.distance}</ThemedText>
                  <ThemedText style={[Typography.caption, { color: theme.textSecondary }]}>Distance</ThemedText>
                </View>
              </View>

              <View style={[styles.routePath, { borderTopColor: theme.divider }]}>
                <View style={styles.pathRow}>
                  <View style={[styles.pathDot, { backgroundColor: SafetyColors.safeGreen }]} />
                  <ThemedText style={Typography.small} numberOfLines={1}>
                    {routeInfo.startAddress}
                  </ThemedText>
                </View>
                <View style={[styles.pathLine, { backgroundColor: theme.divider }]} />
                <View style={styles.pathRow}>
                  <View style={[styles.pathDot, { backgroundColor: SafetyColors.alertRed }]} />
                  <ThemedText style={Typography.small} numberOfLines={1}>
                    {routeInfo.endAddress}
                  </ThemedText>
                </View>
              </View>
            </Card>

            {isTracking ? (
              <Pressable
                style={({ pressed }) => [
                  styles.trackButton,
                  { backgroundColor: SafetyColors.alertRed, opacity: pressed ? 0.8 : 1 },
                ]}
                onPress={handleStopTracking}
              >
                <Feather name="x" size={20} color="#FFFFFF" />
                <ThemedText style={[Typography.button, styles.buttonText]}>Stop Tracking</ThemedText>
              </Pressable>
            ) : (
              <Pressable
                style={({ pressed }) => [
                  styles.trackButton,
                  { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
                  Shadows.medium,
                ]}
                onPress={handleStartTracking}
              >
                <Feather name="play" size={20} color="#FFFFFF" />
                <ThemedText style={[Typography.button, styles.buttonText]}>Start Route Tracking</ThemedText>
              </Pressable>
            )}
          </View>
        ) : null}
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  permissionContainer: {
    alignItems: "center",
    paddingHorizontal: Spacing["2xl"],
  },
  permissionIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  permissionTitle: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  permissionText: {
    textAlign: "center",
    marginBottom: Spacing["2xl"],
  },
  permissionButton: {
    paddingHorizontal: Spacing["2xl"],
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  section: {
    marginBottom: Spacing["2xl"],
  },
  sectionTitle: {
    marginBottom: Spacing.sm,
  },
  trackingCard: {
    padding: Spacing.lg,
    marginBottom: Spacing["2xl"],
  },
  trackingHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  trackingPulse: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: "#FFFFFF",
    marginRight: Spacing.sm,
  },
  locationCard: {
    padding: Spacing.lg,
  },
  locationRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  locationIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  locationInfo: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  refreshButton: {
    padding: Spacing.sm,
  },
  inputCard: {
    padding: Spacing.md,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  destinationInput: {
    flex: 1,
    marginLeft: Spacing.md,
    fontSize: 16,
    height: 40,
  },
  errorCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  calculateButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
    marginBottom: Spacing["2xl"],
  },
  buttonText: {
    color: "#FFFFFF",
  },
  routeCard: {
    padding: 0,
    overflow: "hidden",
  },
  routeStats: {
    flexDirection: "row",
    padding: Spacing.lg,
  },
  routeStat: {
    flex: 1,
    alignItems: "center",
  },
  statValue: {
    marginTop: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  routeDivider: {
    width: 1,
    marginHorizontal: Spacing.lg,
  },
  routePath: {
    padding: Spacing.lg,
    borderTopWidth: 1,
  },
  pathRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  pathDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: Spacing.md,
  },
  pathLine: {
    width: 2,
    height: 24,
    marginLeft: 4,
    marginVertical: Spacing.xs,
  },
  trackButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
    marginTop: Spacing.lg,
  },
});
