import React, { useState } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  FlatList,
  TextInput,
  Modal,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors, Shadows } from "@/constants/theme";
import { apiRequest } from "@/lib/query-client";
import type { EmergencyContact } from "@shared/schema";

const RELATIONSHIPS = ["Parent", "Spouse", "Sibling", "Friend", "Colleague", "Other"];

export default function ContactsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const queryClient = useQueryClient();

  const [modalVisible, setModalVisible] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [relationship, setRelationship] = useState("");
  const [isPrimary, setIsPrimary] = useState(false);

  const { data: contacts = [], isLoading } = useQuery<EmergencyContact[]>({
    queryKey: ["/api/emergency-contacts"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; phoneNumber: string; relationship: string; isPrimary: boolean }) => {
      const response = await apiRequest("POST", "/api/emergency-contacts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      closeModal();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<EmergencyContact> }) => {
      const response = await apiRequest("PATCH", `/api/emergency-contacts/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      closeModal();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/emergency-contacts/${id}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  const openAddModal = () => {
    setEditingContact(null);
    setName("");
    setPhoneNumber("");
    setRelationship("");
    setIsPrimary(false);
    setModalVisible(true);
  };

  const openEditModal = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setName(contact.name);
    setPhoneNumber(contact.phoneNumber);
    setRelationship(contact.relationship || "");
    setIsPrimary(contact.isPrimary || false);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingContact(null);
    setName("");
    setPhoneNumber("");
    setRelationship("");
    setIsPrimary(false);
  };

  const handleSave = () => {
    if (!name.trim() || !phoneNumber.trim()) {
      Alert.alert("Error", "Please fill in name and phone number");
      return;
    }

    const data = {
      name: name.trim(),
      phoneNumber: phoneNumber.trim(),
      relationship: relationship || null,
      isPrimary,
    };

    if (editingContact) {
      updateMutation.mutate({ id: editingContact.id, data });
    } else {
      createMutation.mutate(data as any);
    }
  };

  const handleDelete = (contact: EmergencyContact) => {
    Alert.alert(
      "Delete Contact",
      `Are you sure you want to remove ${contact.name} from your emergency contacts?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deleteMutation.mutate(contact.id),
        },
      ]
    );
  };

  const renderContact = ({ item }: { item: EmergencyContact }) => (
    <Card style={styles.contactCard}>
      <Pressable
        style={styles.contactContent}
        onPress={() => openEditModal(item)}
      >
        <View style={[styles.avatar, { backgroundColor: SafetyColors.safeGreen }]}>
          <ThemedText style={styles.avatarText}>
            {item.name.charAt(0).toUpperCase()}
          </ThemedText>
        </View>
        <View style={styles.contactInfo}>
          <View style={styles.nameRow}>
            <ThemedText style={Typography.bodyMedium}>{item.name}</ThemedText>
            {item.isPrimary ? (
              <View style={[styles.primaryBadge, { backgroundColor: SafetyColors.safeGreen }]}>
                <ThemedText style={styles.badgeText}>Primary</ThemedText>
              </View>
            ) : null}
          </View>
          <ThemedText style={[Typography.small, { color: theme.textSecondary }]}>
            {item.phoneNumber}
          </ThemedText>
          {item.relationship ? (
            <ThemedText style={[Typography.caption, { color: theme.textSecondary }]}>
              {item.relationship}
            </ThemedText>
          ) : null}
        </View>
        <View style={styles.actions}>
          <Pressable
            style={styles.actionButton}
            onPress={() => openEditModal(item)}
          >
            <Feather name="edit-2" size={18} color={theme.textSecondary} />
          </Pressable>
          <Pressable
            style={styles.actionButton}
            onPress={() => handleDelete(item)}
          >
            <Feather name="trash-2" size={18} color={SafetyColors.alertRed} />
          </Pressable>
        </View>
      </Pressable>
    </Card>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <View style={[styles.emptyIcon, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="users" size={48} color={theme.textSecondary} />
      </View>
      <ThemedText style={[Typography.h4, styles.emptyTitle]}>No Emergency Contacts</ThemedText>
      <ThemedText style={[Typography.body, styles.emptySubtitle, { color: theme.textSecondary }]}>
        Add people who will be notified when you trigger an emergency alert
      </ThemedText>
      <Pressable
        style={({ pressed }) => [
          styles.addButton,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={openAddModal}
      >
        <Feather name="plus" size={20} color="#FFFFFF" />
        <ThemedText style={[Typography.button, styles.addButtonText]}>Add Contact</ThemedText>
      </Pressable>
    </View>
  );

  return (
    <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SafetyColors.safeGreen} />
        </View>
      ) : contacts.length === 0 ? (
        <View
          style={[
            styles.content,
            {
              paddingTop: headerHeight + Spacing.xl,
              paddingBottom: tabBarHeight + Spacing.xl,
            },
          ]}
        >
          {renderEmptyState()}
        </View>
      ) : (
        <FlatList
          data={contacts}
          renderItem={renderContact}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing["4xl"],
            paddingHorizontal: Spacing.lg,
          }}
          scrollIndicatorInsets={{ bottom: insets.bottom }}
          ItemSeparatorComponent={() => <View style={{ height: Spacing.md }} />}
        />
      )}

      {contacts.length > 0 ? (
        <Pressable
          style={({ pressed }) => [
            styles.fab,
            {
              backgroundColor: SafetyColors.safeGreen,
              bottom: tabBarHeight + Spacing.xl,
              opacity: pressed ? 0.8 : 1,
            },
            Shadows.fab,
          ]}
          onPress={openAddModal}
        >
          <Feather name="plus" size={28} color="#FFFFFF" />
        </Pressable>
      ) : null}

      <Modal
        visible={modalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={closeModal}
      >
        <ThemedView style={[styles.modalContainer, { backgroundColor: theme.backgroundRoot }]}>
          <View style={[styles.modalHeader, { borderBottomColor: theme.divider }]}>
            <Pressable onPress={closeModal} style={styles.modalButton}>
              <ThemedText style={[Typography.body, { color: theme.link }]}>Cancel</ThemedText>
            </Pressable>
            <ThemedText style={Typography.bodyMedium}>
              {editingContact ? "Edit Contact" : "Add Contact"}
            </ThemedText>
            <Pressable
              onPress={handleSave}
              style={styles.modalButton}
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              {createMutation.isPending || updateMutation.isPending ? (
                <ActivityIndicator size="small" color={SafetyColors.safeGreen} />
              ) : (
                <ThemedText style={[Typography.bodyMedium, { color: SafetyColors.safeGreen }]}>
                  Save
                </ThemedText>
              )}
            </Pressable>
          </View>

          <KeyboardAwareScrollViewCompat
            style={styles.modalScroll}
            contentContainerStyle={styles.modalContent}
          >
            <View style={styles.inputGroup}>
              <ThemedText style={[Typography.small, styles.inputLabel]}>Name</ThemedText>
              <TextInput
                style={[
                  styles.input,
                  { backgroundColor: theme.inputBackground, borderColor: theme.inputBorder, color: theme.text },
                ]}
                placeholder="Contact name"
                placeholderTextColor={theme.textSecondary}
                value={name}
                onChangeText={setName}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={[Typography.small, styles.inputLabel]}>Phone Number</ThemedText>
              <TextInput
                style={[
                  styles.input,
                  { backgroundColor: theme.inputBackground, borderColor: theme.inputBorder, color: theme.text },
                ]}
                placeholder="+1234567890"
                placeholderTextColor={theme.textSecondary}
                keyboardType="phone-pad"
                value={phoneNumber}
                onChangeText={setPhoneNumber}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={[Typography.small, styles.inputLabel]}>Relationship</ThemedText>
              <View style={styles.relationshipGrid}>
                {RELATIONSHIPS.map((rel) => (
                  <Pressable
                    key={rel}
                    style={[
                      styles.relationshipChip,
                      {
                        backgroundColor: relationship === rel ? SafetyColors.safeGreen : theme.backgroundSecondary,
                      },
                    ]}
                    onPress={() => setRelationship(rel)}
                  >
                    <ThemedText
                      style={[
                        Typography.small,
                        { color: relationship === rel ? "#FFFFFF" : theme.text },
                      ]}
                    >
                      {rel}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <Pressable
              style={styles.primaryToggle}
              onPress={() => setIsPrimary(!isPrimary)}
            >
              <View style={styles.toggleLeft}>
                <Feather name="star" size={20} color={isPrimary ? SafetyColors.warningOrange : theme.textSecondary} />
                <View style={styles.toggleText}>
                  <ThemedText style={Typography.bodyMedium}>Primary Contact</ThemedText>
                  <ThemedText style={[Typography.caption, { color: theme.textSecondary }]}>
                    Will be called first in emergencies
                  </ThemedText>
                </View>
              </View>
              <View
                style={[
                  styles.checkbox,
                  {
                    backgroundColor: isPrimary ? SafetyColors.safeGreen : "transparent",
                    borderColor: isPrimary ? SafetyColors.safeGreen : theme.inputBorder,
                  },
                ]}
              >
                {isPrimary ? <Feather name="check" size={14} color="#FFFFFF" /> : null}
              </View>
            </Pressable>
          </KeyboardAwareScrollViewCompat>
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
    justifyContent: "center",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  contactCard: {
    padding: 0,
    overflow: "hidden",
  },
  contactContent: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarText: {
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "600",
  },
  contactInfo: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  primaryBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  badgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "600",
  },
  actions: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  actionButton: {
    padding: Spacing.sm,
  },
  emptyState: {
    alignItems: "center",
    paddingHorizontal: Spacing["2xl"],
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  emptyTitle: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  emptySubtitle: {
    textAlign: "center",
    marginBottom: Spacing["2xl"],
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing["2xl"],
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
  },
  addButtonText: {
    color: "#FFFFFF",
  },
  fab: {
    position: "absolute",
    right: Spacing.lg,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    borderBottomWidth: 1,
  },
  modalButton: {
    minWidth: 60,
  },
  modalScroll: {
    flex: 1,
  },
  modalContent: {
    padding: Spacing.lg,
  },
  inputGroup: {
    marginBottom: Spacing.lg,
  },
  inputLabel: {
    marginBottom: Spacing.xs,
  },
  input: {
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  relationshipGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  relationshipChip: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  primaryToggle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: Spacing.lg,
  },
  toggleLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  toggleText: {
    marginLeft: Spacing.md,
    flex: 1,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
  },
});
