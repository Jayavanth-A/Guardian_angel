import React, { useState, useRef } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors } from "@/constants/theme";
import { apiRequest } from "@/lib/query-client";
import { useAuth } from "@/contexts/AuthContext";

type Step = "phone" | "otp" | "password" | "fingerprint";

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { login, setPassword, setFingerprintEnabled, hasPassword, hasFingerprintEnabled } = useAuth();

  const [step, setStep] = useState<Step>("phone");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [password, setPasswordValue] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [requestId, setRequestId] = useState("");

  const otpRefs = useRef<Array<TextInput | null>>([]);

  const handleSendOTP = async () => {
    if (!phoneNumber || phoneNumber.length < 10) {
      setError("Please enter a valid phone number");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await apiRequest("POST", "/api/auth/send-otp", {
        phoneNumber: phoneNumber.startsWith("+") ? phoneNumber : `+${phoneNumber}`,
      });

      if (response.ok) {
        const data = await response.json();
        setRequestId(data.requestId);
        setStep("otp");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        const errorData = await response.json();
        setError(errorData.message || "Failed to send OTP");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    const otpCode = otp.join("");
    if (otpCode.length !== 6) {
      setError("Please enter the complete 6-digit code");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await apiRequest("POST", "/api/auth/verify-otp", {
        phoneNumber: phoneNumber.startsWith("+") ? phoneNumber : `+${phoneNumber}`,
        code: otpCode,
        requestId,
      });

      if (response.ok) {
        const data = await response.json();
        await login(data.userId, data.phoneNumber);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        
        if (!hasPassword) {
          setStep("password");
        }
      } else {
        const errorData = await response.json();
        setError(errorData.message || "Invalid OTP code");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSetPassword = async () => {
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);
    setError("");

    try {
      await setPassword(password);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setStep("fingerprint");
    } catch (err) {
      setError("Failed to save password");
    } finally {
      setLoading(false);
    }
  };

  const handleSetupFingerprint = async (enable: boolean) => {
    setLoading(true);
    try {
      await setFingerprintEnabled(enable);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError("Failed to set up fingerprint");
    } finally {
      setLoading(false);
    }
  };

  const handleOtpChange = (value: string, index: number) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }

    if (newOtp.every((digit) => digit !== "") && newOtp.join("").length === 6) {
      handleVerifyOTP();
    }
  };

  const getPasswordStrength = () => {
    if (password.length === 0) return null;
    if (password.length < 6) return { label: "Weak", color: SafetyColors.alertRed };
    if (password.length < 10) return { label: "Medium", color: SafetyColors.warningOrange };
    return { label: "Strong", color: SafetyColors.safeGreen };
  };

  const strength = getPasswordStrength();

  const renderPhoneStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <View style={[styles.iconCircle, { backgroundColor: SafetyColors.safeGreen }]}>
          <Feather name="shield" size={48} color="#FFFFFF" />
        </View>
      </View>

      <ThemedText style={[Typography.h2, styles.title]}>SafeGuard</ThemedText>
      <ThemedText style={[Typography.body, styles.subtitle, { color: theme.textSecondary }]}>
        Your personal safety companion
      </ThemedText>

      <View style={styles.inputContainer}>
        <ThemedText style={[Typography.small, styles.label]}>Phone Number</ThemedText>
        <View style={[styles.phoneInputRow, { backgroundColor: theme.inputBackground, borderColor: theme.inputBorder }]}>
          <ThemedText style={styles.countryCode}>+</ThemedText>
          <TextInput
            style={[styles.phoneInput, { color: theme.text }]}
            placeholder="1234567890"
            placeholderTextColor={theme.textSecondary}
            keyboardType="phone-pad"
            value={phoneNumber}
            onChangeText={setPhoneNumber}
            maxLength={15}
          />
        </View>
      </View>

      {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

      <Pressable
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={handleSendOTP}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <ThemedText style={[Typography.button, styles.buttonText]}>Send Verification Code</ThemedText>
        )}
      </Pressable>
    </View>
  );

  const renderOtpStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <View style={[styles.iconCircle, { backgroundColor: SafetyColors.infoBlue }]}>
          <Feather name="message-circle" size={48} color="#FFFFFF" />
        </View>
      </View>

      <ThemedText style={[Typography.h3, styles.title]}>Enter Verification Code</ThemedText>
      <ThemedText style={[Typography.body, styles.subtitle, { color: theme.textSecondary }]}>
        We sent a 6-digit code to {phoneNumber}
      </ThemedText>

      <View style={styles.otpContainer}>
        {otp.map((digit, index) => (
          <TextInput
            key={index}
            ref={(ref) => (otpRefs.current[index] = ref)}
            style={[
              styles.otpInput,
              { 
                backgroundColor: theme.inputBackground, 
                borderColor: digit ? SafetyColors.safeGreen : theme.inputBorder,
                color: theme.text,
              },
            ]}
            keyboardType="number-pad"
            maxLength={1}
            value={digit}
            onChangeText={(value) => handleOtpChange(value, index)}
            onKeyPress={({ nativeEvent }) => {
              if (nativeEvent.key === "Backspace" && !digit && index > 0) {
                otpRefs.current[index - 1]?.focus();
              }
            }}
          />
        ))}
      </View>

      {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

      <Pressable
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={handleVerifyOTP}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <ThemedText style={[Typography.button, styles.buttonText]}>Verify Code</ThemedText>
        )}
      </Pressable>

      <Pressable onPress={() => setStep("phone")} style={styles.linkButton}>
        <ThemedText style={[Typography.link, { color: theme.link }]}>Change phone number</ThemedText>
      </Pressable>
    </View>
  );

  const renderPasswordStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <View style={[styles.iconCircle, { backgroundColor: SafetyColors.warningOrange }]}>
          <Feather name="lock" size={48} color="#FFFFFF" />
        </View>
      </View>

      <ThemedText style={[Typography.h3, styles.title]}>Create Your Password</ThemedText>
      <ThemedText style={[Typography.body, styles.subtitle, { color: theme.textSecondary }]}>
        This password will be used to stop emergency alerts
      </ThemedText>

      <View style={styles.inputContainer}>
        <ThemedText style={[Typography.small, styles.label]}>Password</ThemedText>
        <View style={[styles.passwordInputRow, { backgroundColor: theme.inputBackground, borderColor: theme.inputBorder }]}>
          <TextInput
            style={[styles.passwordInput, { color: theme.text }]}
            placeholder="Enter password (min 6 characters)"
            placeholderTextColor={theme.textSecondary}
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={setPasswordValue}
          />
          <Pressable onPress={() => setShowPassword(!showPassword)} style={styles.eyeButton}>
            <Feather name={showPassword ? "eye-off" : "eye"} size={20} color={theme.textSecondary} />
          </Pressable>
        </View>
        {strength ? (
          <View style={styles.strengthRow}>
            <View style={[styles.strengthBar, { backgroundColor: strength.color }]} />
            <ThemedText style={[Typography.caption, { color: strength.color }]}>{strength.label}</ThemedText>
          </View>
        ) : null}
      </View>

      <View style={styles.inputContainer}>
        <ThemedText style={[Typography.small, styles.label]}>Confirm Password</ThemedText>
        <TextInput
          style={[styles.input, { backgroundColor: theme.inputBackground, borderColor: theme.inputBorder, color: theme.text }]}
          placeholder="Re-enter your password"
          placeholderTextColor={theme.textSecondary}
          secureTextEntry
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />
      </View>

      {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

      <Pressable
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={handleSetPassword}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <ThemedText style={[Typography.button, styles.buttonText]}>Set Password</ThemedText>
        )}
      </Pressable>
    </View>
  );

  const renderFingerprintStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <View style={[styles.iconCircle, { backgroundColor: SafetyColors.safeGreen }]}>
          <Feather name="smartphone" size={48} color="#FFFFFF" />
        </View>
      </View>

      <ThemedText style={[Typography.h3, styles.title]}>Enable Biometric Authentication</ThemedText>
      <ThemedText style={[Typography.body, styles.subtitle, { color: theme.textSecondary }]}>
        Use your fingerprint or face to quickly verify your identity when stopping emergencies
      </ThemedText>

      {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

      <Pressable
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: SafetyColors.safeGreen, opacity: pressed ? 0.8 : 1 },
        ]}
        onPress={() => handleSetupFingerprint(true)}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <ThemedText style={[Typography.button, styles.buttonText]}>Enable Biometrics</ThemedText>
        )}
      </Pressable>

      <Pressable onPress={() => handleSetupFingerprint(false)} style={styles.linkButton}>
        <ThemedText style={[Typography.link, { color: theme.textSecondary }]}>Skip for now (not recommended)</ThemedText>
      </Pressable>
    </View>
  );

  return (
    <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + Spacing["3xl"], paddingBottom: insets.bottom + Spacing["2xl"] },
        ]}
      >
        {step === "phone" && renderPhoneStep()}
        {step === "otp" && renderOtpStep()}
        {step === "password" && renderPasswordStep()}
        {step === "fingerprint" && renderFingerprintStep()}
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  stepContainer: {
    alignItems: "center",
  },
  iconContainer: {
    marginBottom: Spacing["2xl"],
  },
  iconCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  subtitle: {
    textAlign: "center",
    marginBottom: Spacing["3xl"],
  },
  inputContainer: {
    width: "100%",
    marginBottom: Spacing.lg,
  },
  label: {
    marginBottom: Spacing.xs,
  },
  input: {
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  phoneInputRow: {
    flexDirection: "row",
    alignItems: "center",
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
  },
  countryCode: {
    fontSize: 16,
    marginRight: Spacing.xs,
  },
  phoneInput: {
    flex: 1,
    fontSize: 16,
    height: "100%",
  },
  passwordInputRow: {
    flexDirection: "row",
    alignItems: "center",
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
  },
  passwordInput: {
    flex: 1,
    fontSize: 16,
    height: "100%",
  },
  eyeButton: {
    padding: Spacing.xs,
  },
  strengthRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.xs,
    gap: Spacing.sm,
  },
  strengthBar: {
    height: 4,
    width: 60,
    borderRadius: 2,
  },
  otpContainer: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing["2xl"],
  },
  otpInput: {
    width: 48,
    height: 56,
    borderWidth: 2,
    borderRadius: BorderRadius.sm,
    textAlign: "center",
    fontSize: 24,
    fontWeight: "600",
  },
  error: {
    color: SafetyColors.alertRed,
    textAlign: "center",
    marginBottom: Spacing.lg,
  },
  button: {
    width: "100%",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
    marginTop: Spacing.lg,
  },
  buttonText: {
    color: "#FFFFFF",
  },
  linkButton: {
    marginTop: Spacing.lg,
    padding: Spacing.sm,
  },
});
