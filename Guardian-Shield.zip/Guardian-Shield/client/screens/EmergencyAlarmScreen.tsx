import React, { useState, useEffect, useRef } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  Animated,
  BackHandler,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as LocalAuthentication from "expo-local-authentication";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors } from "@/constants/theme";
import { useAuth } from "@/contexts/AuthContext";
import { useEmergency } from "@/contexts/EmergencyContext";

export default function EmergencyAlarmScreen() {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { verifyPassword, hasFingerprintEnabled } = useAuth();
  const { 
    isEmergencyActive, 
    currentLocation, 
    smsSent, 
    callsMade, 
    stopEmergency,
    isSilentMode,
  } = useEmergency();

  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState<"password" | "fingerprint">("password");
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);

  const pulseAnim = useRef(new Animated.Value(0.7)).current;

  useEffect(() => {
    const backHandler = BackHandler.addEventListener("hardwareBackPress", () => true);
    return () => backHandler.remove();
  }, []);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 0.7,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    const timer = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handlePasswordVerify = async () => {
    if (!password) {
      setError("Please enter your password");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const isValid = await verifyPassword(password);
      if (isValid) {
        setPasswordVerified(true);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        
        if (hasFingerprintEnabled) {
          setStep("fingerprint");
          handleBiometricAuth();
        } else {
          await stopEmergency();
        }
      } else {
        setError("Incorrect password");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    } catch (err) {
      setError("Failed to verify password");
    } finally {
      setLoading(false);
    }
  };

  const handleBiometricAuth = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: "Verify your identity to stop emergency",
        cancelLabel: "Cancel",
        disableDeviceFallback: true,
      });

      if (result.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        await stopEmergency();
      } else {
        setError("Biometric verification failed. Please try again.");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    } catch (err) {
      setError("Biometric authentication error");
    }
  };

  const opacityStyle = {
    opacity: pulseAnim,
  };

  return (
    <Animated.View style={[styles.container, opacityStyle, { backgroundColor: SafetyColors.alertRed }]}>
      <View style={[styles.content, { paddingTop: insets.top + Spacing["3xl"], paddingBottom: insets.bottom + Spacing["2xl"] }]}>
        <View style={styles.header}>
          <View style={styles.alarmIcon}>
            <Feather name="alert-triangle" size={64} color="#FFFFFF" />
          </View>
          <ThemedText style={[Typography.h1, styles.title]}>EMERGENCY ACTIVE</ThemedText>
          <ThemedText style={[Typography.h2, styles.timer]}>{formatTime(secondsElapsed)}</ThemedText>
        </View>

        <View style={styles.statusSection}>
          <View style={styles.statusItem}>
            <Feather 
              name={smsSent ? "check-circle" : "loader"} 
              size={24} 
              color={smsSent ? "#FFFFFF" : "rgba(255,255,255,0.6)"} 
            />
            <ThemedText style={styles.statusText}>
              {smsSent ? "SMS sent to emergency contacts" : "Sending SMS to contacts..."}
            </ThemedText>
          </View>
          <View style={styles.statusItem}>
            <Feather 
              name={callsMade ? "check-circle" : "loader"} 
              size={24} 
              color={callsMade ? "#FFFFFF" : "rgba(255,255,255,0.6)"} 
            />
            <ThemedText style={styles.statusText}>
              {callsMade ? "Calls made to contacts" : "Calling emergency contacts..."}
            </ThemedText>
          </View>
          <View style={styles.statusItem}>
            <Feather 
              name={currentLocation ? "check-circle" : "loader"} 
              size={24} 
              color={currentLocation ? "#FFFFFF" : "rgba(255,255,255,0.6)"} 
            />
            <ThemedText style={styles.statusText}>
              {currentLocation ? "Location shared" : "Getting location..."}
            </ThemedText>
          </View>
          {isSilentMode ? (
            <View style={styles.statusItem}>
              <Feather name="volume-x" size={24} color="rgba(255,255,255,0.6)" />
              <ThemedText style={styles.statusText}>Silent mode - No alarm sound</ThemedText>
            </View>
          ) : null}
        </View>

        <View style={styles.stopSection}>
          <ThemedText style={[Typography.bodyMedium, styles.stopTitle]}>
            {step === "password" ? "Enter password to stop" : "Verify fingerprint to stop"}
          </ThemedText>

          {step === "password" ? (
            <>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your password"
                  placeholderTextColor="rgba(255,255,255,0.5)"
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={setPassword}
                  onSubmitEditing={handlePasswordVerify}
                  returnKeyType="done"
                />
                <Pressable onPress={() => setShowPassword(!showPassword)} style={styles.eyeButton}>
                  <Feather name={showPassword ? "eye-off" : "eye"} size={20} color="rgba(255,255,255,0.7)" />
                </Pressable>
              </View>

              {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

              <Pressable
                style={({ pressed }) => [
                  styles.stopButton,
                  { opacity: pressed ? 0.8 : 1 },
                ]}
                onPress={handlePasswordVerify}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color={SafetyColors.alertRed} />
                ) : (
                  <ThemedText style={[Typography.button, { color: SafetyColors.alertRed }]}>
                    Stop Emergency
                  </ThemedText>
                )}
              </Pressable>
            </>
          ) : (
            <>
              <View style={styles.fingerprintContainer}>
                <Feather name="smartphone" size={64} color="#FFFFFF" />
                <ThemedText style={styles.fingerprintText}>
                  Place your finger on the sensor
                </ThemedText>
              </View>

              {error ? <ThemedText style={styles.error}>{error}</ThemedText> : null}

              <Pressable
                style={({ pressed }) => [
                  styles.retryButton,
                  { opacity: pressed ? 0.8 : 1 },
                ]}
                onPress={handleBiometricAuth}
              >
                <ThemedText style={[Typography.button, { color: "#FFFFFF" }]}>
                  Try Again
                </ThemedText>
              </Pressable>
            </>
          )}
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  header: {
    alignItems: "center",
    marginBottom: Spacing["3xl"],
  },
  alarmIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  title: {
    color: "#FFFFFF",
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  timer: {
    color: "#FFFFFF",
    textAlign: "center",
  },
  statusSection: {
    backgroundColor: "rgba(0,0,0,0.2)",
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginBottom: Spacing["3xl"],
  },
  statusItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  statusText: {
    color: "#FFFFFF",
    marginLeft: Spacing.md,
    fontSize: 16,
  },
  stopSection: {
    alignItems: "center",
  },
  stopTitle: {
    color: "#FFFFFF",
    marginBottom: Spacing.lg,
    textAlign: "center",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    height: Spacing.inputHeight,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  input: {
    flex: 1,
    color: "#FFFFFF",
    fontSize: 16,
    height: "100%",
  },
  eyeButton: {
    padding: Spacing.xs,
  },
  error: {
    color: "#FFFFFF",
    backgroundColor: "rgba(0,0,0,0.3)",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.lg,
    textAlign: "center",
  },
  stopButton: {
    width: "100%",
    height: Spacing.buttonHeight,
    backgroundColor: "#FFFFFF",
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  fingerprintContainer: {
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  fingerprintText: {
    color: "#FFFFFF",
    marginTop: Spacing.lg,
    fontSize: 16,
  },
  retryButton: {
    width: "100%",
    height: Spacing.buttonHeight,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
});
