import React, { useState, useEffect, useRef } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Platform,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useQuery } from "@tanstack/react-query";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography, SafetyColors, Shadows } from "@/constants/theme";
import { useEmergency } from "@/contexts/EmergencyContext";
import type { EmergencyContact } from "@shared/schema";

type ListeningState = "idle" | "listening" | "triggered";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme, isDark } = useTheme();
  const { isEmergencyActive, triggerEmergency, isSilentMode, setSilentMode } = useEmergency();

  const [listeningState, setListeningState] = useState<ListeningState>("idle");
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const waveAnim = useRef(new Animated.Value(0)).current;

  const { data: contacts = [] } = useQuery<EmergencyContact[]>({
    queryKey: ["/api/emergency-contacts"],
  });

  useEffect(() => {
    if (listeningState === "listening") {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Animated.loop(
        Animated.timing(waveAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        })
      ).start();
    } else {
      pulseAnim.setValue(1);
      waveAnim.setValue(0);
    }
  }, [listeningState]);

  const handleProtectPress = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    if (listeningState === "idle") {
      setListeningState("listening");
    } else if (listeningState === "listening") {
      setListeningState("idle");
    }
  };

  const handleManualTrigger = async () => {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    await triggerEmergency("manual", isSilentMode);
    setListeningState("triggered");
  };

  const getButtonColor = () => {
    switch (listeningState) {
      case "idle":
        return SafetyColors.safeGreen;
      case "listening":
        return SafetyColors.infoBlue;
      case "triggered":
        return SafetyColors.alertRed;
      default:
        return SafetyColors.safeGreen;
    }
  };

  const getButtonText = () => {
    switch (listeningState) {
      case "idle":
        return "PROTECT YOU";
      case "listening":
        return 'Listening for "HELP"';
      case "triggered":
        return "EMERGENCY ACTIVE";
      default:
        return "PROTECT YOU";
    }
  };

  const waveOpacity = waveAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.6, 0],
  });

  const waveScale = waveAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 2],
  });

  return (
    <ThemedView style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <View
        style={[
          styles.content,
          {
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing.xl,
          },
        ]}
      >
        <View style={styles.statusSection}>
          <Card style={styles.statusCard}>
            <View style={styles.statusRow}>
              <View style={[styles.statusDot, { backgroundColor: listeningState === "listening" ? SafetyColors.safeGreen : theme.textSecondary }]} />
              <ThemedText style={Typography.body}>
                {listeningState === "listening" ? "Voice Detection Active" : "Voice Detection Inactive"}
              </ThemedText>
            </View>
            <View style={styles.statusRow}>
              <View style={[styles.statusDot, { backgroundColor: contacts.length > 0 ? SafetyColors.safeGreen : SafetyColors.warningOrange }]} />
              <ThemedText style={Typography.body}>
                {contacts.length} Emergency Contact{contacts.length !== 1 ? "s" : ""} Set
              </ThemedText>
            </View>
          </Card>
        </View>

        <View style={styles.buttonSection}>
          {listeningState === "listening" ? (
            <Animated.View
              style={[
                styles.waveRing,
                {
                  backgroundColor: SafetyColors.infoBlue,
                  opacity: waveOpacity,
                  transform: [{ scale: waveScale }],
                },
              ]}
            />
          ) : null}

          <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
            <Pressable
              style={({ pressed }) => [
                styles.protectButton,
                {
                  backgroundColor: getButtonColor(),
                  opacity: pressed ? 0.9 : 1,
                },
                Shadows.fab,
              ]}
              onPress={handleProtectPress}
              onLongPress={handleManualTrigger}
              delayLongPress={1500}
            >
              <Feather
                name={listeningState === "triggered" ? "alert-triangle" : "mic"}
                size={64}
                color="#FFFFFF"
              />
              <ThemedText style={[Typography.bodyMedium, styles.buttonLabel]}>{getButtonText()}</ThemedText>
            </Pressable>
          </Animated.View>

          <ThemedText style={[Typography.caption, styles.hintText, { color: theme.textSecondary }]}>
            {listeningState === "idle" 
              ? "Tap to start listening. Long press for manual trigger."
              : listeningState === "listening"
              ? 'Say "HELP" to trigger emergency'
              : "Emergency in progress"}
          </ThemedText>
        </View>

        <View style={styles.optionsSection}>
          <Card style={styles.optionCard}>
            <Pressable
              style={styles.optionRow}
              onPress={() => setSilentMode(!isSilentMode)}
            >
              <View style={styles.optionLeft}>
                <Feather 
                  name={isSilentMode ? "volume-x" : "volume-2"} 
                  size={24} 
                  color={theme.text} 
                />
                <View style={styles.optionText}>
                  <ThemedText style={Typography.bodyMedium}>Silent Mode</ThemedText>
                  <ThemedText style={[Typography.caption, { color: theme.textSecondary }]}>
                    Trigger alerts without alarm sound
                  </ThemedText>
                </View>
              </View>
              <View style={[styles.toggle, { backgroundColor: isSilentMode ? SafetyColors.safeGreen : theme.backgroundSecondary }]}>
                <View style={[styles.toggleKnob, { transform: [{ translateX: isSilentMode ? 20 : 0 }] }]} />
              </View>
            </Pressable>
          </Card>
        </View>

        {contacts.length > 0 ? (
          <View style={styles.contactsPreview}>
            <ThemedText style={[Typography.small, styles.sectionTitle, { color: theme.textSecondary }]}>
              EMERGENCY CONTACTS
            </ThemedText>
            <View style={styles.contactAvatars}>
              {contacts.slice(0, 4).map((contact, index) => (
                <View
                  key={contact.id}
                  style={[
                    styles.contactAvatar,
                    { backgroundColor: SafetyColors.safeGreen, marginLeft: index > 0 ? -12 : 0 },
                  ]}
                >
                  <ThemedText style={styles.avatarText}>
                    {contact.name.charAt(0).toUpperCase()}
                  </ThemedText>
                </View>
              ))}
              {contacts.length > 4 ? (
                <View style={[styles.contactAvatar, { backgroundColor: theme.backgroundSecondary, marginLeft: -12 }]}>
                  <ThemedText style={[styles.avatarText, { color: theme.text }]}>
                    +{contacts.length - 4}
                  </ThemedText>
                </View>
              ) : null}
            </View>
          </View>
        ) : null}
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  statusSection: {
    marginBottom: Spacing["2xl"],
  },
  statusCard: {
    padding: Spacing.lg,
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: Spacing.sm,
  },
  buttonSection: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  waveRing: {
    position: "absolute",
    width: Spacing.protectButtonSize,
    height: Spacing.protectButtonSize,
    borderRadius: Spacing.protectButtonSize / 2,
  },
  protectButton: {
    width: Spacing.protectButtonSize,
    height: Spacing.protectButtonSize,
    borderRadius: Spacing.protectButtonSize / 2,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonLabel: {
    color: "#FFFFFF",
    marginTop: Spacing.sm,
    textAlign: "center",
  },
  hintText: {
    marginTop: Spacing.lg,
    textAlign: "center",
  },
  optionsSection: {
    marginBottom: Spacing.lg,
  },
  optionCard: {
    padding: Spacing.lg,
  },
  optionRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  optionLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  optionText: {
    marginLeft: Spacing.md,
    flex: 1,
  },
  toggle: {
    width: 50,
    height: 30,
    borderRadius: 15,
    padding: 2,
    justifyContent: "center",
  },
  toggleKnob: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#FFFFFF",
  },
  contactsPreview: {
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    marginBottom: Spacing.sm,
  },
  contactAvatars: {
    flexDirection: "row",
  },
  contactAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  avatarText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 16,
  },
});
