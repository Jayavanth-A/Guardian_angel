# Design Guidelines: Personal Safety Mobile App

## Architecture Decisions

### Authentication
**Multi-Layer Security Approach:**
1. **Initial Login (First Time Only):**
   - Vonage OTP verification screen
   - Phone number input with country code selector
   - OTP input with 6-digit code
   - Auto-advance on code completion
   
2. **Security Setup (After First Login):**
   - Password creation screen (minimum 6 characters)
   - Biometric (fingerprint) enrollment with visual feedback
   - Store credentials in encrypted secure storage
   
3. **Subsequent App Launches:**
   - Password entry screen
   - Fingerprint verification screen
   - "Forgot Password" option redirects to OTP flow

4. **Account Management:**
   - Profile screen with logout option
   - Security settings to update password/fingerprint
   - No account deletion (safety app - data persistence critical)

### Navigation
**Bottom Tab Navigation (4 tabs):**
1. **Home Tab:** Main dashboard with "Protect You" button
2. **Safe Route Tab:** Route planning and tracking
3. **Contacts Tab:** Emergency contact management
4. **Profile Tab:** User details and settings

**Floating Action Button:**
- Emergency "SOS" button (always accessible, overlays all screens)
- Red, pulsing animation to draw attention
- Positioned bottom-right with safe area inset

### Screen Specifications

#### 1. Login/OTP Screen (Stack-Only Flow)
- **Purpose:** Secure first-time authentication
- **Layout:**
  - Transparent header with app logo
  - Centered content area with:
    - Phone number input with clear country flag icon
    - "Send OTP" button (full width, Material 3 style)
  - OTP input screen with 6 boxes for digits
  - Top inset: insets.top + 80
  - Bottom inset: insets.bottom + 24
- **Components:** TextInput, Button, OTP digit boxes

#### 2. Security Setup Screens
- **Password Setup:**
  - Form with password input (show/hide toggle)
  - Confirm password field
  - Password strength indicator (weak/medium/strong)
  - Submit button in footer area
  - Cancel button in header (left)
  
- **Fingerprint Setup:**
  - Large fingerprint icon animation
  - Status text ("Place finger on sensor")
  - Success/error feedback with haptics
  - Skip option (not recommended, show warning)

#### 3. Home Screen (Main Dashboard)
- **Purpose:** Primary safety control center
- **Layout:**
  - Default Material header with app name
  - Non-scrollable content area
  - Large centered "Protect You" button (200x200dp)
    - Circular shape with microphone icon
    - Gradient background (safe to alert colors)
    - State indicators: Listening/Active/Standby
  - Status card showing: Voice trigger status, Last location update
  - Quick access to emergency contacts (horizontal scroll)
  - Top inset: 16
  - Bottom inset: tabBarHeight + 24
- **Components:** Circular action button, status cards, avatar chips
- **Safe Area:** Top: 16, Bottom: tabBarHeight + 24

#### 4. Safe Route Screen
- **Purpose:** Plan and track safe routes
- **Layout:**
  - Header with search bar for destination
  - Map view (fills remaining screen)
  - Bottom sheet with:
    - Start point (current location, auto-filled)
    - Destination input with autocomplete
    - "Calculate Route" button
    - Route details card (time, distance, deviation alerts)
  - Floating "Start Tracking" button when route selected
  - Top inset: headerHeight + 16
  - Bottom inset: tabBarHeight + 16
- **Components:** Google Maps integration, bottom sheet, search autocomplete

#### 5. Emergency Contacts Screen
- **Purpose:** Manage emergency contact list
- **Layout:**
  - Header with "+ Add Contact" button (right)
  - Scrollable list of contact cards
  - Each card shows:
    - Contact avatar (auto-generated initials)
    - Name and phone number
    - Relationship tag (e.g., "Parent", "Friend")
    - Edit/Delete actions (swipe left)
  - Empty state: Illustration + "Add your first contact"
  - Top inset: 16
  - Bottom inset: tabBarHeight + 24
- **Components:** FlatList, contact cards, swipe actions

#### 6. Profile Screen
- **Purpose:** User details for identification and settings
- **Layout:**
  - Header with "Edit" button (right)
  - Scrollable form with sections:
    - Personal Details: Photo, Name, Age, Gender
    - Physical Characteristics: Height, Weight, Skin tone, Eye color, Distinguishing marks
    - Security: Change password, Update fingerprint, Logout
  - Submit button below form (when editing)
  - Top inset: 16
  - Bottom inset: tabBarHeight + 80
- **Components:** Form inputs, image picker, dropdown selectors

#### 7. Emergency Alarm Screen (Modal)
- **Purpose:** Active emergency alert interface
- **Layout:**
  - Full-screen modal (covers all content)
  - Red pulsing background
  - Large "EMERGENCY ACTIVE" text
  - Countdown showing seconds elapsed
  - Status indicators:
    - SMS sent to X contacts ✓
    - Calling contacts... (with loading)
    - Location shared ✓
  - "Stop Alarm" button (requires password + fingerprint)
  - Cannot be dismissed by back button
- **Components:** Modal overlay, status checklist, secure input

## Design System

### Color Palette
**Primary Colors:**
- **Safe Green:** #2E7D32 (primary state, success)
- **Alert Red:** #C62828 (danger, emergency states)
- **Warning Orange:** #F57C00 (caution, route deviation)

**Neutral Colors:**
- **Background:** #FAFAFA (Material light background)
- **Surface:** #FFFFFF (cards, sheets)
- **Text Primary:** #212121
- **Text Secondary:** #757575
- **Divider:** #E0E0E0

**Accent Colors:**
- **Info Blue:** #1976D2 (informational states)
- **Success Light:** #66BB6A (confirmation feedback)

### Typography
- **Headings:** Roboto Bold (Material default)
  - H1: 32sp (Profile name)
  - H2: 24sp (Screen titles)
  - H3: 20sp (Card titles)
- **Body:** Roboto Regular
  - Body 1: 16sp (Primary content)
  - Body 2: 14sp (Secondary content)
- **Buttons:** Roboto Medium, 16sp, uppercase
- **Captions:** Roboto Regular, 12sp (hints, timestamps)

### Visual Design
- **Icons:** Material Icons from @expo/vector-icons
  - Voice: microphone-outline
  - Emergency: alert-circle
  - Location: map-marker
  - Fingerprint: fingerprint
  - Security: shield-checkmark
- **Shadows for Floating Elements:**
  - Floating Action Button (SOS):
    - shadowOffset: {width: 0, height: 4}
    - shadowOpacity: 0.30
    - shadowRadius: 8
    - elevation: 8
  - Bottom Sheet:
    - shadowOffset: {width: 0, height: -2}
    - shadowOpacity: 0.10
    - shadowRadius: 4
    - elevation: 4
- **Touchable Feedback:**
  - All buttons use Material Ripple effect
  - Emergency buttons: red ripple
  - Safe actions: green ripple
  - Default: gray ripple

### Critical Assets
1. **App Logo:** Safety shield icon with gradient (green to blue)
2. **Empty State Illustrations:**
   - No emergency contacts: Person with phone illustration
   - No route selected: Map with route line illustration
3. **Voice Listening Animation:** Concentric circles pulsing from microphone icon
4. **Emergency Alarm Animation:** Red pulsing overlay with siren icon rotation

### Interaction Design
- **"Protect You" Button States:**
  - Standby: Static green with white mic icon
  - Listening: Pulsing animation with sound wave circles
  - Triggered: Red with alarm icon, vibration pattern
- **Emergency Alert Trigger:**
  - Haptic feedback (strong vibration pattern)
  - Audio alarm (loud, continuous)
  - Visual: Full-screen red overlay
- **Biometric Authentication:**
  - Show fingerprint scanner animation
  - Success: Green checkmark with haptic
  - Failure: Red shake animation with error haptic

### Accessibility Requirements
- **High Contrast Mode:** Support for emergency visibility
- **Large Touch Targets:** Minimum 48x48dp for all interactive elements
- **Emergency Button:** 200x200dp for easy panic access
- **Screen Reader Support:** All critical actions labeled
- **Haptic Feedback:** Required for all security actions and emergency triggers
- **Permission Warnings:** Clear explanations for location, microphone, biometric, SMS, phone access
- **Offline Support:** Core emergency features work without internet (local SMS/calls)