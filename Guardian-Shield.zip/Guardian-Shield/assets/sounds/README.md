Alarm sound placeholder
