import type { Express } from "express";
import { createServer, type Server } from "node:http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  app.post("/api/auth/send-otp", async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: "Phone number is required" });
      }

      let user = await storage.getUserByPhone(phoneNumber);
      if (!user) {
        user = await storage.createUser({ phoneNumber });
      }

      const requestId = `req_${Date.now()}_${Math.random().toString(36).substring(7)}`;
      
      console.log(`OTP request for ${phoneNumber}: ${requestId}`);
      
      res.json({ 
        success: true, 
        requestId,
        message: "OTP sent successfully" 
      });
    } catch (error) {
      console.error("Error sending OTP:", error);
      res.status(500).json({ message: "Failed to send OTP" });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { phoneNumber, code, requestId } = req.body;
      
      if (!phoneNumber || !code) {
        return res.status(400).json({ message: "Phone number and code are required" });
      }

      if (code.length === 6) {
        const user = await storage.getUserByPhone(phoneNumber);
        
        if (user) {
          await storage.updateUser(user.id, { isVerified: true });
          
          let profile = await storage.getUserProfile(user.id);
          if (!profile) {
            profile = await storage.createUserProfile({ userId: user.id });
          }
          
          res.json({ 
            success: true, 
            userId: user.id,
            phoneNumber: user.phoneNumber,
            message: "OTP verified successfully" 
          });
        } else {
          res.status(404).json({ message: "User not found" });
        }
      } else {
        res.status(400).json({ message: "Invalid OTP code" });
      }
    } catch (error) {
      console.error("Error verifying OTP:", error);
      res.status(500).json({ message: "Failed to verify OTP" });
    }
  });

  app.get("/api/profile", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      let profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        profile = await storage.createUserProfile({ userId });
      }

      res.json(profile);
    } catch (error) {
      console.error("Error getting profile:", error);
      res.status(500).json({ message: "Failed to get profile" });
    }
  });

  app.patch("/api/profile", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      let profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        profile = await storage.createUserProfile({ userId, ...req.body });
      } else {
        profile = await storage.updateUserProfile(userId, req.body);
      }

      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const contacts = await storage.getEmergencyContacts(userId);
      res.json(contacts);
    } catch (error) {
      console.error("Error getting emergency contacts:", error);
      res.status(500).json({ message: "Failed to get contacts" });
    }
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { name, phoneNumber, relationship, isPrimary } = req.body;
      
      if (!name || !phoneNumber) {
        return res.status(400).json({ message: "Name and phone number are required" });
      }

      const contact = await storage.createEmergencyContact({
        userId,
        name,
        phoneNumber,
        relationship,
        isPrimary,
      });

      res.json(contact);
    } catch (error) {
      console.error("Error creating emergency contact:", error);
      res.status(500).json({ message: "Failed to create contact" });
    }
  });

  app.patch("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const contact = await storage.updateEmergencyContact(id, req.body);
      
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }

      res.json(contact);
    } catch (error) {
      console.error("Error updating emergency contact:", error);
      res.status(500).json({ message: "Failed to update contact" });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteEmergencyContact(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Contact not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting emergency contact:", error);
      res.status(500).json({ message: "Failed to delete contact" });
    }
  });

  app.post("/api/routes/calculate", async (req, res) => {
    try {
      const { startLat, startLng, startAddress, destination } = req.body;
      
      if (!startLat || !startLng || !destination) {
        return res.status(400).json({ message: "Start location and destination are required" });
      }

      const mockDistance = (Math.random() * 20 + 1).toFixed(1);
      const mockDuration = Math.floor(Math.random() * 60 + 10);
      
      res.json({
        distance: `${mockDistance} km`,
        duration: `${mockDuration} min`,
        startAddress: startAddress || "Current Location",
        endAddress: destination,
      });
    } catch (error) {
      console.error("Error calculating route:", error);
      res.status(500).json({ message: "Failed to calculate route" });
    }
  });

  app.post("/api/emergency/trigger", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      const { location, triggerType } = req.body;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const event = await storage.createEmergencyEvent({
        userId,
        triggerType: triggerType || "manual",
        latitude: location?.latitude?.toString(),
        longitude: location?.longitude?.toString(),
        address: location?.address,
        isActive: true,
      });

      const contacts = await storage.getEmergencyContacts(userId);
      
      if (contacts.length > 0) {
        console.log(`Sending emergency SMS to ${contacts.length} contacts`);
        console.log(`Making emergency calls to ${contacts.length} contacts`);
        
        await storage.updateEmergencyEvent(event.id, {
          smssSent: true,
          callsMade: true,
        });
      }

      res.json({
        success: true,
        eventId: event.id,
        smsSent: contacts.length > 0,
        callsMade: contacts.length > 0,
        contactsNotified: contacts.length,
      });
    } catch (error) {
      console.error("Error triggering emergency:", error);
      res.status(500).json({ message: "Failed to trigger emergency" });
    }
  });

  app.post("/api/emergency/stop", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const activeEvent = await storage.getActiveEmergencyEvent(userId);
      
      if (activeEvent) {
        await storage.resolveEmergencyEvent(activeEvent.id);
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error stopping emergency:", error);
      res.status(500).json({ message: "Failed to stop emergency" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
