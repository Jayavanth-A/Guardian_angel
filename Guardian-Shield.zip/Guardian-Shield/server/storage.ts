import { 
  users, 
  userProfiles,
  emergencyContacts,
  savedRoutes,
  emergencyEvents,
  type User, 
  type InsertUser,
  type UserProfile,
  type InsertUserProfile,
  type EmergencyContact,
  type InsertEmergencyContact,
  type SavedRoute,
  type InsertSavedRoute,
  type EmergencyEvent,
  type InsertEmergencyEvent,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phoneNumber: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;
  
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: string, data: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  
  getEmergencyContacts(userId: string): Promise<EmergencyContact[]>;
  getEmergencyContact(id: string): Promise<EmergencyContact | undefined>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  updateEmergencyContact(id: string, data: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: string): Promise<boolean>;
  
  getSavedRoutes(userId: string): Promise<SavedRoute[]>;
  createSavedRoute(route: InsertSavedRoute): Promise<SavedRoute>;
  deleteSavedRoute(id: string): Promise<boolean>;
  
  createEmergencyEvent(event: InsertEmergencyEvent): Promise<EmergencyEvent>;
  getActiveEmergencyEvent(userId: string): Promise<EmergencyEvent | undefined>;
  resolveEmergencyEvent(id: string): Promise<EmergencyEvent | undefined>;
  updateEmergencyEvent(id: string, data: Partial<InsertEmergencyEvent>): Promise<EmergencyEvent | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByPhone(phoneNumber: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phoneNumber, phoneNumber));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile || undefined;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const [created] = await db
      .insert(userProfiles)
      .values(profile)
      .returning();
    return created;
  }

  async updateUserProfile(userId: string, data: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const [profile] = await db
      .update(userProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile || undefined;
  }

  async getEmergencyContacts(userId: string): Promise<EmergencyContact[]> {
    return db.select().from(emergencyContacts).where(eq(emergencyContacts.userId, userId));
  }

  async getEmergencyContact(id: string): Promise<EmergencyContact | undefined> {
    const [contact] = await db.select().from(emergencyContacts).where(eq(emergencyContacts.id, id));
    return contact || undefined;
  }

  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    const [created] = await db
      .insert(emergencyContacts)
      .values(contact)
      .returning();
    return created;
  }

  async updateEmergencyContact(id: string, data: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined> {
    const [contact] = await db
      .update(emergencyContacts)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(emergencyContacts.id, id))
      .returning();
    return contact || undefined;
  }

  async deleteEmergencyContact(id: string): Promise<boolean> {
    const result = await db.delete(emergencyContacts).where(eq(emergencyContacts.id, id)).returning();
    return result.length > 0;
  }

  async getSavedRoutes(userId: string): Promise<SavedRoute[]> {
    return db.select().from(savedRoutes).where(eq(savedRoutes.userId, userId)).orderBy(desc(savedRoutes.createdAt));
  }

  async createSavedRoute(route: InsertSavedRoute): Promise<SavedRoute> {
    const [created] = await db
      .insert(savedRoutes)
      .values(route)
      .returning();
    return created;
  }

  async deleteSavedRoute(id: string): Promise<boolean> {
    const result = await db.delete(savedRoutes).where(eq(savedRoutes.id, id)).returning();
    return result.length > 0;
  }

  async createEmergencyEvent(event: InsertEmergencyEvent): Promise<EmergencyEvent> {
    const [created] = await db
      .insert(emergencyEvents)
      .values(event)
      .returning();
    return created;
  }

  async getActiveEmergencyEvent(userId: string): Promise<EmergencyEvent | undefined> {
    const [event] = await db
      .select()
      .from(emergencyEvents)
      .where(and(eq(emergencyEvents.userId, userId), eq(emergencyEvents.isActive, true)))
      .orderBy(desc(emergencyEvents.createdAt))
      .limit(1);
    return event || undefined;
  }

  async resolveEmergencyEvent(id: string): Promise<EmergencyEvent | undefined> {
    const [event] = await db
      .update(emergencyEvents)
      .set({ isActive: false, resolvedAt: new Date() })
      .where(eq(emergencyEvents.id, id))
      .returning();
    return event || undefined;
  }

  async updateEmergencyEvent(id: string, data: Partial<InsertEmergencyEvent>): Promise<EmergencyEvent | undefined> {
    const [event] = await db
      .update(emergencyEvents)
      .set(data)
      .where(eq(emergencyEvents.id, id))
      .returning();
    return event || undefined;
  }
}

export const storage = new DatabaseStorage();
